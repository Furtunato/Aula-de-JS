let a = parseInt(prompt("Digite o 1 valor: "))
let b = parseInt(prompt("Digite o 2 valor: "))
alert(`A soma é ${(a + b)}`);




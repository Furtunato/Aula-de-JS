let prova1 = parseInt(prompt("O resulado da prova foi! *peso 6"))
let prova2 = parseInt(prompt("O resultado da prova 2 foi! *peso 10"))
let simulado = parseInt(prompt("O resultado do simulado foi! *peso 4"))

let media = ((prova1 + prova2 + simulado)) / 2;
alert(`A media é: ${media}`);
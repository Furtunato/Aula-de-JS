let bolacha = parseInt(prompt('Valor da bolacha é: '))
let suco = parseInt(prompt("Valor do suco é: "))
alert(`A soma dos dois produtos é ${(bolacha + suco)}`);

function alterarSinal() {
    let numero = document.getElementById('numero').value;
    document.getElementById('mensagem').innerHTML = '';
    if (numero == 1) {
        document.getElementById('mensagem').innerHTML = 'Vermelho'; 
    } else if (numero == 2) {
        document.getElementById('mensagem').innerHTML = 'Laranja'; 
    } else if (numero == 3) {
        document.getElementById('mensagem').innerHTML = 'Verde'; 
    } else {
        document.getElementById('mensagem').innerHTML = 'Numeros do 1 ao 3!';
    }
}

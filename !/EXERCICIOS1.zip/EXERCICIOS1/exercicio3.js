//Exercício 3: Operador ! (NÃO)
let z = true;

console.log(!z); // false
console.log(!false); // true
console.log(!(z && false)); // true
console.log(!z || false); // false
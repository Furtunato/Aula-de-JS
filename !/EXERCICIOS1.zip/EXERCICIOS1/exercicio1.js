//Exercício 1: Operador && (E)
let a = true;
let b = false;

console.log(a && b); // false
console.log(a && true); // true
console.log(b && false); // false 
console.log(a && (b || true)); // true





let idade = parseFloat(prompt("Digite sua idade: "));

if (idade >= 18) {
alert ("Voce e maior de idade e tem CNH")

} else {
    alert("Voce e menor de idade")
}
    
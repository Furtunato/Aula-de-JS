function botao1 (){
    alert("Voce apertou no botao 1")
}
    function botao2(){
        alert("Voce apertou no botao 2")
    }
        function botao3 (){
            alert("Voce apertou no botao3")
        }